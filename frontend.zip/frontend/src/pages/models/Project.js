export class Project{
    constructor(name, type, budget, description){
        this.name = name;
        this.type = type;
        this.budget = budget;
        this.description = description;
    }
}